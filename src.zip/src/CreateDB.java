import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDB {
    Connection database;

    public CreateDB(String host, String port, String user, String dbName) throws SQLException, ClassNotFoundException {

        Connection server = this.connectToServer(host, port, user);
        this.database = this.createDB(server, host, port, user, dbName);
    }


    private Connection connectToServer(String host, String port, String user) throws SQLException, ClassNotFoundException {
        String url = "jdbc:postgresql://" + host + ":" + port + "/" + user;
        Class.forName("org.postgresql.Driver");
        return DriverManager.getConnection(url);
    }

    private Connection createDB(Connection server, String host, String port, String user, String dbName) throws SQLException {
        Statement createDB = server.createStatement();
        String createDBBuilder = "CREATE DATABASE " + dbName +
                "\n\tWITH \n\tOWNER = " +
                user +
                "\n\tENCODING = 'UTF8';";
        createDB.executeUpdate(createDBBuilder);
        server.close();
        String url = "jdbc:postgresql://" + host + ":" + port + "/" + user;
        return DriverManager.getConnection(url);
    }

    private void createSchemaAndTables() throws IOException {
        String regexForSQLSplit = "((?<=;)|(?=;))";
        BufferedReader fileReader = new BufferedReader(new FileReader("../sql/createAndLoad.sql"));
        StringBuffer fileBuffer = new StringBuffer();
        String line;
        while((line = fileReader.readLine()) != null){
            fileBuffer.append(line);
        }
        String[] statements = fileBuffer.toString().split(regexForSQLSplit);
    }

    private void loadTables(){

    }
}
