import java.sql.SQLException;

public class Application {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        new CreateDB("localhost", "5432", "postgres", "practice");
    }
}
